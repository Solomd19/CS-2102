public interface ISet {

    ISet addElt(String Elt);
    boolean hasElt(String Elt);
    int size();

}

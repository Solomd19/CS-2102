class AVLGuest extends DataBST{

    AVLGuest(String data, IBST left, IBST right){
        super(data, left, right);
        balance();
    }

    void balance(){
        //too complex for this amount of lab time lol
    }
}
public class Task2 {

//    Class Mouse
//    LinkedList<Double> Experiment = new LinkedList<Experiment>();
//
//    Class Experiment
//    String date;
//    double weight;
//    Workout dailyWorkout;
//    Food dailyRations;
//
//    Class Workout
//    int minutes;
//    int workouts;
//
//    Class Food
//    String type;
//    double grams;


}
